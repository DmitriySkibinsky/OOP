﻿namespace MeasuringDevice
{
    public enum Units
    {
        Metric,
        Imperial
    }
}

